import 'package:flutter/material.dart';
import 'package:pos_qr_table_ordering/config/shimmer.dart';

class HouseView extends StatefulWidget {
  const HouseView({super.key});

  @override
  State<HouseView> createState() => _HouseViewState();
}

class _HouseViewState extends State<HouseView> {
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(hours: 5), () {
      if (mounted) setState(() => isLoading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('House View')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: isLoading ? const _SkeletonBody() : const _RealBody(),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// Skeleton — shown while loading
// ─────────────────────────────────────────────
class _SkeletonBody extends StatelessWidget {
  const _SkeletonBody();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Section: single line (e.g. page title) ──
        Column(
          spacing: 8,
          children: [
            const ShimmerLine(height: 20, width: 160),
            const ShimmerLine(height: 20, width: 160),
          ],
        ),
        const SizedBox(height: 20),

        // ── Section: avatar + name row ──
        const ShimmerListTile(),
        const SizedBox(height: 20),

        // ── Section: banner image ──
        const ShimmerBox(width: double.infinity, height: 180, borderRadius: 12),
        const SizedBox(height: 20),

        // ── Section: paragraph description ──
        const ShimmerParagraph(lines: 3),
        const SizedBox(height: 20),

        // ── Section: custom colored shimmer (e.g. price tag / badge) ──
        Shimmer(
          height: 36,
          width: 120,
          borderRadius: 20,
          config: const ShimmerConfig(
            lightColors: [
              Color.fromARGB(255, 9, 45, 208),
              Color(0xFFEEF1FF),
              Color.fromARGB(255, 227, 11, 11),
              Color.fromARGB(239, 7, 49, 239),
              Color(0xFFDDE3FF),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // ── Section: 2-column grid ──
        const ShimmerGrid(
          itemCount: 4,
          crossAxisCount: 2,
          childAspectRatio: 1.1,
          imageHeight: 90,
        ),
        const SizedBox(height: 20),

        // ── Section: 3-column grid (compact) ──
        const ShimmerGrid(
          itemCount: 6,
          crossAxisCount: 3,
          childAspectRatio: 0.8,
          imageHeight: 80,
          spacing: 8,
        ),
        const SizedBox(height: 20),

        //  ── Section: card list wrapped in ShimmerTheme ──
        ShimmerTheme(
          config: const ShimmerConfig(
            duration: Duration(milliseconds: 1000),
            lightColors: [
              Color(0xFFEEEEEE),
              Color(0xFFF8F8F8),
              Color(0xFFFFFFFF),
              Color(0xFFF8F8F8),
              Color(0xFFEEEEEE),
            ],
          ),
          child: Column(
            children: List.generate(
              3,
              (_) => const Padding(
                padding: EdgeInsets.only(bottom: 12),
                child: ShimmerCard(),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────
// Real content — shown after loading
// ─────────────────────────────────────────────
class _RealBody extends StatelessWidget {
  const _RealBody();

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Real content here'));
  }
}
