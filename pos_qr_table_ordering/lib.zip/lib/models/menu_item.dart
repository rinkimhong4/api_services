import 'package:flutter/material.dart';

class CategoryItem {
  final String id;
  final String name;
  final IconData icon;
  final Color color;

  const CategoryItem({
    required this.id,
    required this.name,
    required this.icon,
    required this.color,
  });
}

class MenuItem {
  final String id;
  final String title;
  final String description;
  final double price;
  final double? originalPrice;
  final String categoryId;
  final String imageUrl;
  final double rating;
  final int reviewCount;
  final bool isPopular;
  final bool isNew;

  const MenuItem({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    this.originalPrice,
    required this.categoryId,
    required this.imageUrl,
    required this.rating,
    required this.reviewCount,
    this.isPopular = false,
    this.isNew = false,
  });

  bool get hasDiscount => originalPrice != null && originalPrice! > price;

  int get discountPercentage {
    if (!hasDiscount) return 0;
    return (((originalPrice! - price) / originalPrice!) * 100).round();
  }
}

final List<CategoryItem> sampleCategories = [
  const CategoryItem(
    id: 'all',
    name: 'All Menu',
    icon: Icons.grid_view_rounded,
    color: Color(0xFFFF5252),
  ),
  const CategoryItem(
    id: 'coffee',
    name: 'Espresso & Coffee',
    icon: Icons.local_cafe_rounded,
    color: Color(0xFF8D6E63),
  ),
  const CategoryItem(
    id: 'tea',
    name: 'Milk Tea & Boba',
    icon: Icons.emoji_food_beverage_rounded,
    color: Color(0xFF66BB6A),
  ),
  const CategoryItem(
    id: 'cold_brew',
    name: 'Cold Brew',
    icon: Icons.ac_unit_rounded,
    color: Color(0xFF42A5F5),
  ),
  const CategoryItem(
    id: 'bakery',
    name: 'Fresh Bakery',
    icon: Icons.bakery_dining_rounded,
    color: Color(0xFFFFB74D),
  ),
  const CategoryItem(
    id: 'smoothie',
    name: 'Smoothies & Juice',
    icon: Icons.local_drink_rounded,
    color: Color(0xFFAB47BC),
  ),
];

final List<MenuItem> sampleMenuItems = [
  const MenuItem(
    id: 'm1',
    title: 'Iced Caramel Macchiato',
    description: 'Freshly brewed espresso with steamed milk, vanilla syrup, and rich caramel drizzle served over ice.',
    price: 3.80,
    originalPrice: 4.50,
    categoryId: 'coffee',
    imageUrl: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=600&auto=format&fit=crop&q=80',
    rating: 4.9,
    reviewCount: 128,
    isPopular: true,
  ),
  const MenuItem(
    id: 'm2',
    title: 'Matcha Green Tea Latte',
    description: 'Premium Japanese ceremonial grade matcha whisked with creamy milk and lightly sweetened.',
    price: 4.20,
    originalPrice: 4.90,
    categoryId: 'tea',
    imageUrl: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=600&auto=format&fit=crop&q=80',
    rating: 4.8,
    reviewCount: 95,
    isPopular: true,
  ),
  const MenuItem(
    id: 'm3',
    title: 'Signature Cold Brew',
    description: 'Slow-steeped for 20 hours to extract smooth, sweet, bold flavor with ultra-low acidity.',
    price: 3.50,
    categoryId: 'cold_brew',
    imageUrl: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=600&auto=format&fit=crop&q=80',
    rating: 4.7,
    reviewCount: 84,
  ),
  const MenuItem(
    id: 'm4',
    title: 'Brown Sugar Boba Milk Tea',
    description: 'Chewy tapioca pearls in rich caramelized brown sugar syrup with fresh full-cream milk.',
    price: 4.50,
    originalPrice: 5.20,
    categoryId: 'tea',
    imageUrl: 'https://images.unsplash.com/photo-1558857563-b371033873b8?w=600&auto=format&fit=crop&q=80',
    rating: 4.9,
    reviewCount: 210,
    isPopular: true,
  ),
  const MenuItem(
    id: 'm5',
    title: 'Butter Croissant',
    description: 'Flaky, buttery French pastry baked golden brown with crisp outer layers and soft inside.',
    price: 2.80,
    categoryId: 'bakery',
    imageUrl: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=600&auto=format&fit=crop&q=80',
    rating: 4.6,
    reviewCount: 64,
  ),
  const MenuItem(
    id: 'm6',
    title: 'Strawberry Dragonfruit Smoothie',
    description: 'Blend of real strawberries, organic dragonfruit, banana, and coconut water.',
    price: 4.90,
    categoryId: 'smoothie',
    imageUrl: 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?w=600&auto=format&fit=crop&q=80',
    rating: 4.8,
    reviewCount: 76,
    isNew: true,
  ),
  const MenuItem(
    id: 'm7',
    title: 'Iced Vanilla Americano',
    description: 'Double shot espresso combined with cold water, ice, and subtle Madagascar vanilla flavor.',
    price: 3.20,
    categoryId: 'coffee',
    imageUrl: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=600&auto=format&fit=crop&q=80',
    rating: 4.5,
    reviewCount: 52,
  ),
  const MenuItem(
    id: 'm8',
    title: 'Chocolate Fudge Muffin',
    description: 'Moist rich dark chocolate muffin packed with Belgian chocolate chunks.',
    price: 3.10,
    originalPrice: 3.60,
    categoryId: 'bakery',
    imageUrl: 'https://images.unsplash.com/photo-1607958996333-41aef7caefaa?w=600&auto=format&fit=crop&q=80',
    rating: 4.7,
    reviewCount: 88,
  ),
];
