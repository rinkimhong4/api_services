import 'package:flutter/foundation.dart';
import 'package:pos_qr_table_ordering/models/menu_item.dart';

class CartOrderItem {
  final MenuItem item;
  final String size;
  final String sugarLevel;
  final String iceLevel;
  final double unitPrice;
  int quantity;

  CartOrderItem({
    required this.item,
    this.size = 'Medium',
    this.sugarLevel = '100%',
    this.iceLevel = 'Normal Ice',
    required this.unitPrice,
    this.quantity = 1,
  });

  double get totalPrice => unitPrice * quantity;
}

class CartState extends ChangeNotifier {
  static final CartState instance = CartState._();
  CartState._();

  final List<CartOrderItem> _items = [];
  String tableNumber = "Table 05";
  String customerNote = "";

  List<CartOrderItem> get items => List.unmodifiable(_items);

  int get totalItemCount => _items.fold(0, (sum, item) => sum + item.quantity);

  double get subtotal => _items.fold(0.0, (sum, item) => sum + item.totalPrice);

  double get taxAmount => subtotal * 0.05; // 5% tax/service charge

  double get grandTotal => subtotal + taxAmount;

  void addItem(
    MenuItem item, {
    String size = 'Medium',
    String sugarLevel = '100%',
    String iceLevel = 'Normal Ice',
    double? unitPrice,
    int quantity = 1,
  }) {
    final double price = unitPrice ?? item.price;
    final existingIndex = _items.indexWhere(
      (e) =>
          e.item.id == item.id &&
          e.size == size &&
          e.sugarLevel == sugarLevel &&
          e.iceLevel == iceLevel,
    );

    if (existingIndex >= 0) {
      _items[existingIndex].quantity += quantity;
    } else {
      _items.add(
        CartOrderItem(
          item: item,
          size: size,
          sugarLevel: sugarLevel,
          iceLevel: iceLevel,
          unitPrice: price,
          quantity: quantity,
        ),
      );
    }
    notifyListeners();
  }

  void updateQuantity(int index, int newQuantity) {
    if (index >= 0 && index < _items.length) {
      if (newQuantity <= 0) {
        _items.removeAt(index);
      } else {
        _items[index].quantity = newQuantity;
      }
      notifyListeners();
    }
  }

  void removeItem(int index) {
    if (index >= 0 && index < _items.length) {
      _items.removeAt(index);
      notifyListeners();
    }
  }

  void clearCart() {
    _items.clear();
    customerNote = "";
    notifyListeners();
  }
}
