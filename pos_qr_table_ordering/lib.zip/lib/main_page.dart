import 'dart:io';
import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pos_qr_table_ordering/models/cart_state.dart';
import 'package:pos_qr_table_ordering/pages/order_lists_page.dart';
import 'package:pos_qr_table_ordering/pages/pos_qr_order_home_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> with TickerProviderStateMixin {
  int _selectedIndex = 0;
  final bool _isIOS = Platform.isIOS;
  final List<Widget> _pages = [
    const PosQrOrderHomePage(),
    const OrderListsPage(),
  ];

  List<Map<String, dynamic>> get navItems => [
    {
      "icon": _isIOS ? CupertinoIcons.house : Icons.home_outlined,
      "activeIcon": _isIOS ? CupertinoIcons.house_fill : Icons.home_rounded,
      "label": "Home",
    },
    {
      "icon": _isIOS ? CupertinoIcons.square_list : Icons.receipt_long_outlined,
      "activeIcon": _isIOS
          ? CupertinoIcons.square_list_fill
          : Icons.receipt_long_rounded,
      "label": "Orders",
    },
  ];

  void _onTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      backgroundColor: const Color(0xFFF8FAFC),

      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 350),
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeInCubic,
        child: _pages[_selectedIndex],
      ),

      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(left: 60, right: 60, bottom: 24),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(50),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              height: 72,
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(50),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.25),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                children: List.generate(navItems.length, (index) {
                  final bool isSelected = _selectedIndex == index;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => _onTap(index),
                      behavior: HitTestBehavior.translucent,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        curve: Curves.easeOutCubic,
                        margin: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: isSelected
                              ? Colors.white.withValues(alpha: 0.15)
                              : Colors.transparent,
                        ),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Icon(
                                      isSelected
                                          ? navItems[index]["activeIcon"]
                                          : navItems[index]["icon"],
                                      size: 22,
                                      color: isSelected
                                          ? Colors.white
                                          : Colors.white54,
                                    ),
                                    if (index == 1) // Orders tab badge
                                      ListenableBuilder(
                                        listenable: CartState.instance,
                                        builder: (context, _) {
                                          final count =
                                              CartState.instance.totalItemCount;
                                          if (count == 0) {
                                            return const SizedBox.shrink();
                                          }
                                          return Positioned(
                                            right: -8,
                                            top: -6,
                                            child: Container(
                                              padding: const EdgeInsets.all(4),
                                              decoration: const BoxDecoration(
                                                color: Color(0xFFFF5252),
                                                shape: BoxShape.circle,
                                              ),
                                              child: Text(
                                                count.toString(),
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  navItems[index]["label"],
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: isSelected
                                        ? FontWeight.w700
                                        : FontWeight.w400,
                                    color: isSelected
                                        ? Colors.white
                                        : Colors.white54,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
