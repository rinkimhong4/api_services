// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';

// class DashBoardUi extends StatelessWidget {
//   const DashBoardUi({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final usdFormat = NumberFormat.currency(locale: 'en_US', symbol: '\$');

//     final khrFormat = NumberFormat.currency(
//       locale: 'km_KH',
//       symbol: '៛',
//       decimalDigits: 0,
//     );

//     final gradients = [
//       [const Color(0xFF3B82F6), const Color(0xFF06B6D4)],
//       [const Color(0xFF8B5CF6), const Color(0xFFEC4899)],
//       [const Color(0xFF10B981), const Color(0xFF14B8A6)],
//       [const Color(0xFFF97316), const Color(0xFFEF4444)],
//     ];

//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: false,
//         leading: Padding(
//           padding: const EdgeInsets.all(4.0),
//           child: CircleAvatar(radius: 24, child: Icon(Icons.person)),
//         ),
//         title: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               "Good Morning 👋",
//               style: Theme.of(context).textTheme.bodyMedium,
//             ),
//             Text(
//               "Kimhong Rin",
//               style: Theme.of(
//                 context,
//               ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
//             ),
//           ],
//         ),
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.only(bottom: 20),
//         child: Column(
//           children: [
//             const SizedBox(height: 20),

//             /// Balance Card
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               child: Container(
//                 width: double.infinity,
//                 padding: const EdgeInsets.all(24),
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(24),
//                   gradient: const LinearGradient(
//                     colors: [Color(0xFF3B82F6), Color(0xFF06B6D4)],
//                   ),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.blue.withValues(alpha: 0.25),
//                       blurRadius: 20,
//                       offset: const Offset(0, 10),
//                     ),
//                   ],
//                 ),
//                 child: Column(
//                   children: [
//                     const Text(
//                       "Total Balance",
//                       style: TextStyle(color: Colors.white70, fontSize: 16),
//                     ),
//                     const SizedBox(height: 10),

//                     Text(
//                       usdFormat.format(12580.25),
//                       style: const TextStyle(
//                         color: Colors.white,
//                         fontSize: 34,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),

//                     Text(
//                       khrFormat.format(51200900),
//                       style: const TextStyle(
//                         color: Colors.white70,
//                         fontSize: 18,
//                       ),
//                     ),

//                     const SizedBox(height: 24),

//                     Row(
//                       children: [
//                         Expanded(
//                           child: _SummaryItem(
//                             title: "Income",
//                             value: "\$12,500",
//                             icon: Icons.arrow_downward,
//                           ),
//                         ),
//                         const SizedBox(width: 10),
//                         Expanded(
//                           child: _SummaryItem(
//                             title: "Expense",
//                             value: "\$8,200",
//                             icon: Icons.arrow_upward,
//                           ),
//                         ),
//                         const SizedBox(width: 10),
//                         Expanded(
//                           child: _SummaryItem(
//                             title: "Profit",
//                             value: "\$4,300",
//                             icon: Icons.trending_up,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),
//             ),

//             const SizedBox(height: 30),

//             /// Dashboard Cards
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               child: Row(
//                 children: [
//                   Text(
//                     "Overview",
//                     style: Theme.of(context).textTheme.titleLarge,
//                   ),
//                 ],
//               ),
//             ),

//             const SizedBox(height: 12),

//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               child: Wrap(
//                 spacing: 12,
//                 runSpacing: 12,
//                 children: List.generate(
//                   4,
//                   (index) => SizedBox(
//                     width: (MediaQuery.of(context).size.width - 44) / 2,
//                     child: DashBoardCardWidget(
//                       title: [
//                         "Wallet",
//                         "Savings",
//                         "Inventory",
//                         "Customers",
//                       ][index],
//                       icon: [
//                         Icons.account_balance_wallet,
//                         Icons.savings,
//                         Icons.inventory_2,
//                         Icons.people,
//                       ][index],
//                       totalUSD: 1250.50 * (index + 1),
//                       totalKHR: 5120090 * (index + 1),
//                       gradientColors: gradients[index],
//                     ),
//                   ),
//                 ),
//               ),
//             ),

//             const SizedBox(height: 30),

//             /// Recent Transactions
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               child: Row(
//                 children: [
//                   Text(
//                     "Recent Transactions",
//                     style: Theme.of(context).textTheme.titleLarge,
//                   ),
//                 ],
//               ),
//             ),

//             const SizedBox(height: 10),

//             Card(
//               margin: const EdgeInsets.symmetric(horizontal: 16),
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(20),
//               ),
//               child: Column(
//                 children: const [
//                   _TransactionTile(
//                     title: "Salary",
//                     amount: "+ \$500",
//                     icon: Icons.payments,
//                     isIncome: true,
//                   ),
//                   Divider(height: 1),
//                   _TransactionTile(
//                     title: "Shopping",
//                     amount: "- \$45",
//                     icon: Icons.shopping_bag,
//                     isIncome: false,
//                   ),
//                   Divider(height: 1),
//                   _TransactionTile(
//                     title: "Fuel",
//                     amount: "- \$10",
//                     icon: Icons.local_gas_station,
//                     isIncome: false,
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class _QuickAction extends StatelessWidget {
//   final IconData icon;
//   final String label;

//   const _QuickAction({required this.icon, required this.label});

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         CircleAvatar(radius: 26, child: Icon(icon)),
//         const SizedBox(height: 6),
//         Text(label),
//       ],
//     );
//   }
// }

// class _SummaryItem extends StatelessWidget {
//   final String title;
//   final String value;
//   final IconData icon;

//   const _SummaryItem({
//     required this.title,
//     required this.value,
//     required this.icon,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
//       decoration: BoxDecoration(
//         color: Colors.white.withValues(alpha: .15),
//         borderRadius: BorderRadius.circular(14),
//       ),
//       child: Column(
//         children: [
//           Icon(icon, color: Colors.white),
//           const SizedBox(height: 6),
//           Text(title, style: const TextStyle(color: Colors.white70)),
//           const SizedBox(height: 4),
//           Text(
//             value,
//             style: const TextStyle(
//               color: Colors.white,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class DashBoardCardWidget extends StatelessWidget {
//   const DashBoardCardWidget({
//     super.key,
//     required this.title,
//     required this.icon,
//     required this.totalUSD,
//     required this.totalKHR,
//     required this.gradientColors,
//   });

//   final String title;
//   final IconData icon;
//   final double totalUSD;
//   final double totalKHR;
//   final List<Color> gradientColors;

//   @override
//   Widget build(BuildContext context) {
//     final usdFormat = NumberFormat.currency(locale: 'en_US', symbol: '\$');

//     final khrFormat = NumberFormat.currency(
//       locale: 'km_KH',
//       symbol: '៛',
//       decimalDigits: 0,
//     );

//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(20),
//         gradient: LinearGradient(colors: gradientColors),
//         boxShadow: [
//           BoxShadow(
//             color: gradientColors.first.withValues(alpha: .25),
//             blurRadius: 15,
//             offset: const Offset(0, 8),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           CircleAvatar(
//             backgroundColor: Colors.white.withValues(alpha: .2),
//             child: Icon(icon, color: Colors.white),
//           ),
//           const SizedBox(height: 16),

//           Text(
//             title,
//             style: const TextStyle(
//               color: Colors.white,
//               fontWeight: FontWeight.w600,
//             ),
//           ),

//           const SizedBox(height: 10),

//           Text(
//             usdFormat.format(totalUSD),
//             style: const TextStyle(
//               color: Colors.white,
//               fontSize: 20,
//               fontWeight: FontWeight.bold,
//             ),
//           ),

//           Text(
//             khrFormat.format(totalKHR),
//             style: const TextStyle(color: Colors.white70),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class _TransactionTile extends StatelessWidget {
//   final String title;
//   final String amount;
//   final IconData icon;
//   final bool isIncome;

//   const _TransactionTile({
//     required this.title,
//     required this.amount,
//     required this.icon,
//     required this.isIncome,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       leading: CircleAvatar(child: Icon(icon)),
//       title: Text(title),
//       subtitle: const Text("Today"),
//       trailing: Text(
//         amount,
//         style: TextStyle(
//           color: isIncome ? Colors.green : Colors.red,
//           fontWeight: FontWeight.bold,
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// ── Formatters (shared, not re-created per-widget) ──────────────────────────
final _usd = NumberFormat.currency(locale: 'en_US', symbol: '\$');
final _khr = NumberFormat.currency(
  locale: 'km_KH',
  symbol: '៛',
  decimalDigits: 0,
);

// ── Data model ───────────────────────────────────────────────────────────────
class _CardData {
  const _CardData({
    required this.title,
    required this.icon,
    required this.totalUSD,
    required this.totalKHR,
    required this.colors,
  });

  final String title;
  final IconData icon;
  final double totalUSD;
  final double totalKHR;
  final List<Color> colors;
}

const _cards = <_CardData>[
  _CardData(
    title: 'Wallet',
    icon: Icons.account_balance_wallet_rounded,
    totalUSD: 1250.50,
    totalKHR: 51276780090,
    colors: [Color(0xFF6C63FF), Color(0xFF48CAE4)],
  ),
  _CardData(
    title: 'Savings',
    icon: Icons.savings_rounded,
    totalUSD: 8430.00,
    totalKHR: 34521600,
    colors: [Color(0xFF11998E), Color(0xFF38EF7D)],
  ),
  _CardData(
    title: 'Revenue',
    icon: Icons.bar_chart_rounded,
    totalUSD: 42750.25,
    totalKHR: 175072525,
    colors: [Color(0xFFFC5C7D), Color(0xFF6A82FB)],
  ),
  _CardData(
    title: 'Expenses',
    icon: Icons.receipt_long_rounded,
    totalUSD: 3100.75,
    totalKHR: 12693175,
    colors: [Color(0xFFFF9966), Color(0xFFFF5E62)],
  ),
];

// ── Screen ───────────────────────────────────────────────────────────────────
class DashBoardUi extends StatelessWidget {
  const DashBoardUi({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: _buildAppBar(context),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _GreetingHeader(),
              const SizedBox(height: 16),
              const _BalanceCard(
                totalUSD: 5120.09,
                totalKHR: 5120090,
                income: 127548.35,
                expense: 12578.67,
                profit: 1250.50,
              ),
              const SizedBox(height: 24),
              _SectionLabel('Accounts'),
              const SizedBox(height: 12),
              _CardGrid(cards: _cards),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: const Color(0xFFF5F6FA),
      elevation: 0,
      scrolledUnderElevation: 0,
      title: Text(
        'Dashboard',
        style: Theme.of(context).textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w700,
          color: const Color(0xFF1A1D2E),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.notifications_none_rounded),
          color: const Color(0xFF1A1D2E),
          onPressed: () {},
        ),
        const Padding(
          padding: EdgeInsets.only(right: 12),
          child: CircleAvatar(
            radius: 18,
            backgroundColor: Color(0xFF6C63FF),
            child: Text(
              'H',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ── Greeting ─────────────────────────────────────────────────────────────────
class _GreetingHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Good morning, Hong 👋',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w700,
            color: const Color(0xFF1A1D2E),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          'Here\'s your financial overview',
          style: Theme.of(
            context,
          ).textTheme.bodyMedium?.copyWith(color: const Color(0xFF8A8FA8)),
        ),
      ],
    );
  }
}

// ── Section label ─────────────────────────────────────────────────────────────
class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.w700,
        color: const Color(0xFF1A1D2E),
      ),
    );
  }
}

// ── Balance card ──────────────────────────────────────────────────────────────
class _BalanceCard extends StatelessWidget {
  const _BalanceCard({
    required this.totalUSD,
    required this.totalKHR,
    required this.income,
    required this.expense,
    required this.profit,
  });

  final double totalUSD;
  final double totalKHR;
  final double income;
  final double expense;
  final double profit;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A1D2E), Color(0xFF2D3153)],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1A1D2E).withValues(alpha: 0.35),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Total Balance',
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'This Month',
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Balances
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              _usd.format(totalUSD),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 34,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.5,
              ),
            ),
          ),
          const SizedBox(height: 2),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              _khr.format(totalKHR),
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.55),
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),

          const SizedBox(height: 20),
          const Divider(color: Colors.white12),
          const SizedBox(height: 16),

          // Stats row
          Row(
            children: [
              _BalanceStat(
                label: 'Income',
                value: _usd.format(income),
                icon: Icons.arrow_downward_rounded,
                iconColor: const Color(0xFF38EF7D),
              ),
              const SizedBox(width: 1),
              _VerticalDivider(),
              const SizedBox(width: 1),
              _BalanceStat(
                label: 'Expense',
                value: _usd.format(expense),
                icon: Icons.arrow_upward_rounded,
                iconColor: const Color(0xFFFC5C7D),
              ),
              const SizedBox(width: 1),
              _VerticalDivider(),
              const SizedBox(width: 1),
              _BalanceStat(
                label: 'Profit',
                value: _usd.format(profit),
                icon: Icons.trending_up_rounded,
                iconColor: const Color(0xFFFFD166),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _BalanceStat extends StatelessWidget {
  const _BalanceStat({
    required this.label,
    required this.value,
    required this.icon,
    required this.iconColor,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: iconColor, size: 14),
              const SizedBox(width: 4),
              Text(
                label,
                style: const TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _VerticalDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 36, color: Colors.white12);
  }
}

// ── Account cards grid ────────────────────────────────────────────────────────
class _CardGrid extends StatelessWidget {
  const _CardGrid({required this.cards});
  final List<_CardData> cards;

  @override
  Widget build(BuildContext context) {
    final cardWidth = (MediaQuery.of(context).size.width - 16 * 2 - 12) / 2;

    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: cards
          .map(
            (c) => SizedBox(
              width: cardWidth,
              child: DashBoardCardWidget(
                title: c.title,
                icon: c.icon,
                totalUSD: c.totalUSD,
                totalKHR: c.totalKHR,
                gradientColors: c.colors,
              ),
            ),
          )
          .toList(),
    );
  }
}

// ── Reusable account card ─────────────────────────────────────────────────────
class DashBoardCardWidget extends StatelessWidget {
  const DashBoardCardWidget({
    super.key,
    required this.title,
    required this.icon,
    required this.totalUSD,
    required this.totalKHR,
    this.gradientColors,
  });

  final String title;
  final IconData icon;
  final double totalUSD;
  final double totalKHR;
  final List<Color>? gradientColors;

  @override
  Widget build(BuildContext context) {
    final colors = gradientColors ?? [const Color(0xFF1A1D2E), Colors.purple];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: colors,
        ),
        boxShadow: [
          BoxShadow(
            color: colors.first.withValues(alpha: 0.30),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Icon + title row
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: 0.2),
                ),
                child: Icon(icon, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // USD
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              _usd.format(totalUSD),
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Colors.white,
                letterSpacing: -0.3,
              ),
            ),
          ),

          const SizedBox(height: 2),

          // KHR
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              _khr.format(totalKHR),
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Colors.white,
                letterSpacing: -0.3,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
