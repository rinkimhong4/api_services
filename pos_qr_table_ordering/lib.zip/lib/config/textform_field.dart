import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// Basic
// AppTextField(
//   label: 'Full Name',
//   hint: 'Enter your name',
//   prefixIcon: Icons.person_outline,

//   validator: (v) => v!.isEmpty ? 'Required' : null,
//   onChanged: (v) => {
//     //
//   },
// ),

// // Password
// AppTextField.password(
//   controller: _passController,
//   validator: (v) => v!.length < 6 ? 'Min 6 chars' : null,
// ),

// // Search
// AppTextField.search(
//   controller: _searchController,
//   hint: 'Search properties...',
//   onChanged: (v) => {
//     //
//   },
// ),

// // Per-instance style override
// AppTextField(
//   label: 'Price',
//   prefixIcon: Icons.attach_money,
//   style: AppTextFieldStyle(
//     focusedBorderColor: Color(0xFF00C853),
//     borderRadius: 14,
//   ),
// ),

// Screen-wide theme
// AppTextFieldTheme(
//   style: AppTextFieldStyle(
//     focusedBorderColor: Color(0xFF3D5AFE),
//     borderRadius: 12,
//     fillColor: Colors.white,
//   ),
//   child: YourFormScreen(),
// ),

// ─────────────────────────────────────────────
// AppTextField — reusable TextFormField wrapper
// ─────────────────────────────────────────────
class AppTextField extends StatefulWidget {
  // ── Controller & value ──
  final TextEditingController? controller;
  final String? initialValue;

  // ── Labels ──
  final String? label;
  final String? hint;
  final String? helper;

  // ── Icons ──
  final IconData? prefixIcon;
  final Widget? suffixIcon;

  // ── Behavior ──
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final List<TextInputFormatter>? inputFormatters;
  final bool obscureText;
  final bool readOnly;
  final bool enabled;
  final int maxLines;
  final int? maxLength;
  final FocusNode? focusNode;

  // ── Callbacks ──
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  final void Function(String)? onSubmitted;
  final void Function()? onTap;

  // ── Style overrides ──
  final AppTextFieldStyle? style;

  const AppTextField({
    super.key,
    this.controller,
    this.initialValue,
    this.label,
    this.hint,
    this.helper,
    this.prefixIcon,
    this.suffixIcon,
    this.keyboardType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.inputFormatters,
    this.obscureText = false,
    this.readOnly = false,
    this.enabled = true,
    this.maxLines = 1,
    this.maxLength,
    this.focusNode,
    this.validator,
    this.onChanged,
    this.onSubmitted,
    this.onTap,
    this.style,
  });

  /// Password field — auto-adds show/hide toggle.
  factory AppTextField.password({
    Key? key,
    TextEditingController? controller,
    String? label,
    String? hint,
    String? Function(String?)? validator,
    void Function(String)? onChanged,
    AppTextFieldStyle? style,
  }) => _PasswordTextField(
    key: key,
    controller: controller,
    label: label ?? 'Password',
    hint: hint ?? 'Enter password',
    validator: validator,
    onChanged: onChanged,
    style: style,
  );

  /// Search field — magnifier prefix, clear suffix.
  factory AppTextField.search({
    Key? key,
    TextEditingController? controller,
    String? hint,
    void Function(String)? onChanged,
    void Function(String)? onSubmitted,
    AppTextFieldStyle? style,
  }) => _SearchTextField(
    key: key,
    controller: controller,
    hint: hint ?? 'Search...',
    onChanged: onChanged,
    onSubmitted: onSubmitted,
    style: style,
  );

  @override
  State<AppTextField> createState() => _AppTextFieldState();
}

class _AppTextFieldState extends State<AppTextField> {
  @override
  Widget build(BuildContext context) {
    final s = widget.style ?? AppTextFieldStyle.of(context);
    return _FieldShell(
      label: widget.label,
      style: s,
      child: TextFormField(
        controller: widget.controller,
        initialValue: widget.initialValue,
        focusNode: widget.focusNode,
        keyboardType: widget.keyboardType,
        textInputAction: widget.textInputAction,
        inputFormatters: widget.inputFormatters,
        obscureText: widget.obscureText,
        readOnly: widget.readOnly,
        enabled: widget.enabled,
        maxLines: widget.maxLines,
        maxLength: widget.maxLength,
        validator: widget.validator,
        onChanged: widget.onChanged,
        onFieldSubmitted: widget.onSubmitted,
        onTap: widget.onTap,
        style: s.inputTextStyle,
        decoration: _buildDecoration(s),
      ),
    );
  }

  InputDecoration _buildDecoration(AppTextFieldStyle s) {
    return InputDecoration(
      hintText: widget.hint,
      hintStyle: s.hintStyle,
      helperText: widget.helper,
      helperStyle: s.helperStyle,
      prefixIcon: widget.prefixIcon != null
          ? Icon(widget.prefixIcon, size: s.iconSize, color: s.iconColor)
          : null,
      suffixIcon: widget.suffixIcon,
      filled: true,
      fillColor: widget.enabled ? s.fillColor : s.disabledFillColor,
      contentPadding: s.contentPadding,
      border: _border(s.borderColor, s.borderRadius),
      enabledBorder: _border(s.borderColor, s.borderRadius),
      focusedBorder: _border(s.focusedBorderColor, s.borderRadius, width: 1.5),
      errorBorder: _border(s.errorColor, s.borderRadius),
      focusedErrorBorder: _border(s.errorColor, s.borderRadius, width: 1.5),
      disabledBorder: _border(s.disabledBorderColor, s.borderRadius),
      errorStyle: TextStyle(color: s.errorColor, fontSize: 12),
    );
  }

  OutlineInputBorder _border(Color color, double radius, {double width = 1.0}) {
    return OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius),
      borderSide: BorderSide(color: color, width: width),
    );
  }
}

// ─────────────────────────────────────────────
// Password variant
// ─────────────────────────────────────────────
class _PasswordTextField extends AppTextField {
  const _PasswordTextField({
    super.key,
    super.controller,
    super.label,
    super.hint,
    super.validator,
    super.onChanged,
    super.style,
  }) : super(obscureText: true);

  @override
  State<AppTextField> createState() => _PasswordState();
}

class _PasswordState extends _AppTextFieldState {
  bool _visible = false;

  @override
  Widget build(BuildContext context) {
    final s = widget.style ?? AppTextFieldStyle.of(context);
    return _FieldShell(
      label: widget.label,
      style: s,
      child: TextFormField(
        controller: widget.controller,
        focusNode: widget.focusNode,
        keyboardType: TextInputType.visiblePassword,
        textInputAction: widget.textInputAction,
        obscureText: !_visible,
        validator: widget.validator,
        onChanged: widget.onChanged,
        style: s.inputTextStyle,
        decoration: _buildDecoration(s).copyWith(
          suffixIcon: IconButton(
            icon: Icon(
              _visible
                  ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
              size: s.iconSize,
              color: s.iconColor,
            ),
            onPressed: () => setState(() => _visible = !_visible),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// Search variant
// ─────────────────────────────────────────────
class _SearchTextField extends AppTextField {
  const _SearchTextField({
    super.key,
    super.controller,
    super.hint,
    super.onChanged,
    super.onSubmitted,
    super.style,
  }) : super(
         prefixIcon: Icons.search_rounded,
         keyboardType: TextInputType.text,
         textInputAction: TextInputAction.search,
       );

  @override
  State<AppTextField> createState() => _SearchState();
}

class _SearchState extends _AppTextFieldState {
  @override
  Widget build(BuildContext context) {
    final s = widget.style ?? AppTextFieldStyle.of(context);
    return TextFormField(
      controller: widget.controller,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.search,
      onChanged: widget.onChanged,
      onFieldSubmitted: widget.onSubmitted,
      style: s.inputTextStyle,
      decoration: _buildDecoration(s).copyWith(
        suffixIcon: widget.controller != null
            ? ValueListenableBuilder<TextEditingValue>(
                valueListenable: widget.controller!,
                builder: (_, value, __) => value.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(
                          Icons.close_rounded,
                          size: s.iconSize,
                          color: s.iconColor,
                        ),
                        onPressed: () {
                          widget.controller!.clear();
                          widget.onChanged?.call('');
                        },
                      )
                    : const SizedBox.shrink(),
              )
            : null,
      ),
    );
  }
}

// ─────────────────────────────────────────────
// Optional floating label shell
// ─────────────────────────────────────────────
class _FieldShell extends StatelessWidget {
  final String? label;
  final AppTextFieldStyle style;
  final Widget child;

  const _FieldShell({
    required this.label,
    required this.style,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    if (label == null) return child;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label!, style: style.labelStyle),
        const SizedBox(height: 6),
        child,
      ],
    );
  }
}

// ─────────────────────────────────────────────
// AppTextFieldStyle — all visuals in one place
// ─────────────────────────────────────────────
class AppTextFieldStyle {
  final double borderRadius;
  final Color borderColor;
  final Color focusedBorderColor;
  final Color errorColor;
  final Color disabledBorderColor;
  final Color fillColor;
  final Color disabledFillColor;
  final Color iconColor;
  final double iconSize;
  final EdgeInsetsGeometry contentPadding;
  final TextStyle inputTextStyle;
  final TextStyle hintStyle;
  final TextStyle labelStyle;
  final TextStyle helperStyle;

  const AppTextFieldStyle({
    this.borderRadius = 10,
    this.borderColor = const Color(0xFFDDDDDD),
    this.focusedBorderColor = const Color(0xFF3D5AFE),
    this.errorColor = const Color(0xFFE53935),
    this.disabledBorderColor = const Color(0xFFEEEEEE),
    this.fillColor = const Color(0xFFFAFAFA),
    this.disabledFillColor = const Color(0xFFF5F5F5),
    this.iconColor = const Color(0xFF9E9E9E),
    this.iconSize = 20,
    this.contentPadding = const EdgeInsets.symmetric(
      horizontal: 14,
      vertical: 14,
    ),
    this.inputTextStyle = const TextStyle(
      fontSize: 14,
      color: Color(0xFF212121),
    ),
    this.hintStyle = const TextStyle(fontSize: 14, color: Color(0xFFBDBDBD)),
    this.labelStyle = const TextStyle(
      fontSize: 13,
      fontWeight: FontWeight.w500,
      color: Color(0xFF424242),
    ),
    this.helperStyle = const TextStyle(fontSize: 12, color: Color(0xFF9E9E9E)),
  });

  /// Grab the nearest [AppTextFieldTheme] or fall back to defaults.
  static AppTextFieldStyle of(BuildContext context) {
    return context
            .dependOnInheritedWidgetOfExactType<AppTextFieldTheme>()
            ?.style ??
        const AppTextFieldStyle();
  }

  AppTextFieldStyle copyWith({
    double? borderRadius,
    Color? borderColor,
    Color? focusedBorderColor,
    Color? errorColor,
    Color? disabledBorderColor,
    Color? fillColor,
    Color? disabledFillColor,
    Color? iconColor,
    double? iconSize,
    EdgeInsetsGeometry? contentPadding,
    TextStyle? inputTextStyle,
    TextStyle? hintStyle,
    TextStyle? labelStyle,
    TextStyle? helperStyle,
  }) => AppTextFieldStyle(
    borderRadius: borderRadius ?? this.borderRadius,
    borderColor: borderColor ?? this.borderColor,
    focusedBorderColor: focusedBorderColor ?? this.focusedBorderColor,
    errorColor: errorColor ?? this.errorColor,
    disabledBorderColor: disabledBorderColor ?? this.disabledBorderColor,
    fillColor: fillColor ?? this.fillColor,
    disabledFillColor: disabledFillColor ?? this.disabledFillColor,
    iconColor: iconColor ?? this.iconColor,
    iconSize: iconSize ?? this.iconSize,
    contentPadding: contentPadding ?? this.contentPadding,
    inputTextStyle: inputTextStyle ?? this.inputTextStyle,
    hintStyle: hintStyle ?? this.hintStyle,
    labelStyle: labelStyle ?? this.labelStyle,
    helperStyle: helperStyle ?? this.helperStyle,
  );
}

// ─────────────────────────────────────────────
// AppTextFieldTheme — provide style to subtree
// ─────────────────────────────────────────────
class AppTextFieldTheme extends InheritedWidget {
  final AppTextFieldStyle style;

  const AppTextFieldTheme({
    super.key,
    required this.style,
    required super.child,
  });

  @override
  bool updateShouldNotify(AppTextFieldTheme old) => style != old.style;
}
