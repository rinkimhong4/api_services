import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'local_storage_service.dart';

// ─────────────────────────────────────────────────────────────
//  Demo page
// ─────────────────────────────────────────────────────────────
class StorageDemoPage extends StatefulWidget {
  const StorageDemoPage({super.key});
  @override
  State<StorageDemoPage> createState() => _StorageDemoPageState();
}

class _StorageDemoPageState extends State<StorageDemoPage> {
  final _storage = LocalStorageService.instance;
  final _nameCtrl = TextEditingController();
  final _ageCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();

  String? _savedName;
  int? _savedAge;
  double? _savedPrice;
  File? _savedImage;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    setState(() {
      _savedName = _storage.getString('user_name');
      _savedAge = _storage.getInt('user_age');
      _savedPrice = _storage.getDouble('item_price');
    });
    _savedImage = await _storage.getImage('profile_pic');
    setState(() {});
  }

  Future<void> _saveAll() async {
    await _storage.setString('user_name', _nameCtrl.text.trim());
    await _storage.setInt('user_age', int.tryParse(_ageCtrl.text) ?? 0);
    await _storage.setDouble(
      'item_price',
      double.tryParse(_priceCtrl.text) ?? 0.0,
    );
    _loadAll();
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Saved!')));
    }
  }

  Future<void> _pickAndSaveImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;
    final file = await _storage.saveImageFile('profile_pic', File(picked.path));
    setState(() => _savedImage = file);
  }

  Future<void> _deleteImage() async {
    await _storage.deleteImage('profile_pic');
    setState(() => _savedImage = null);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('LocalStorage Demo')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // ── String ──────────────────────────────
          _SectionTitle('String'),
          TextField(
            controller: _nameCtrl,
            decoration: const InputDecoration(
              labelText: 'Name',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person_outline),
            ),
          ),
          if (_savedName != null) ...[
            const SizedBox(height: 6),
            _SavedChip('Saved: $_savedName'),
          ],
          const SizedBox(height: 16),

          // ── Int ──────────────────────────────────
          _SectionTitle('Int (number)'),
          TextField(
            controller: _ageCtrl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Age',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.numbers),
            ),
          ),
          if (_savedAge != null) ...[
            const SizedBox(height: 6),
            _SavedChip('Saved: $_savedAge'),
          ],
          const SizedBox(height: 16),

          // ── Double ───────────────────────────────
          _SectionTitle('Double (decimal)'),
          TextField(
            controller: _priceCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Price',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.attach_money),
            ),
          ),
          if (_savedPrice != null) ...[
            const SizedBox(height: 6),
            _SavedChip('Saved: \$${_savedPrice!.toStringAsFixed(2)}'),
          ],
          const SizedBox(height: 20),

          // ── Save button ──────────────────────────
          FilledButton.icon(
            onPressed: _saveAll,
            icon: const Icon(Icons.save_alt, color: Colors.red),
            label: const Text(
              'Save String & Numbers',
              style: TextStyle(color: Colors.red),
            ),
          ),
          const SizedBox(height: 28),

          // ── Image ────────────────────────────────
          _SectionTitle('Image'),
          if (_savedImage != null) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(
                _savedImage!,
                height: 180,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _savedImage!.path,
              style: Theme.of(context).textTheme.bodySmall,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),
          ] else
            Container(
              height: 120,
              decoration: BoxDecoration(
                color: cs.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  'No image saved',
                  style: TextStyle(color: cs.onSurfaceVariant),
                ),
              ),
            ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickAndSaveImage,
                  icon: const Icon(Icons.upload_rounded),
                  label: const Text('Upload & Save'),
                ),
              ),
              if (_savedImage != null) ...[
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _deleteImage,
                    style: OutlinedButton.styleFrom(foregroundColor: cs.error),
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Delete Image'),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  Small helpers
// ─────────────────────────────────────────────────────────────
class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      text,
      style: Theme.of(
        context,
      ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
    ),
  );
}

class _SavedChip extends StatelessWidget {
  final String label;
  const _SavedChip(this.label);
  @override
  Widget build(BuildContext context) => Chip(
    label: Text(label),
    avatar: const Icon(Icons.check_circle_outline, size: 16),
    visualDensity: VisualDensity.compact,
  );
}
