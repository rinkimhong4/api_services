import 'package:flutter/material.dart';

// ─────────────────────────────────────────────
// ShimmerConfig — tweak everything in one place
// ─────────────────────────────────────────────
class ShimmerConfig {
  /// Light-mode gradient colors (base → highlight → base)
  final List<Color> lightColors;

  /// Dark-mode gradient colors (base → highlight → base)
  final List<Color> darkColors;

  /// Color stops matching the colors list length
  final List<double> stops;

  /// How long one sweep takes
  final Duration duration;

  /// Animation curve
  final Curve curve;

  const ShimmerConfig({
    this.lightColors = const [
      Color(0xFFE8E8E8),
      Color(0xFFF4F4F4),
      Color(0xFFFFFFFF),
      Color(0xFFF4F4F4),
      Color(0xFFE8E8E8),
    ],
    this.darkColors = const [
      Color(0xFF1E1E1E),
      Color(0xFF2C2C2C),
      Color(0xFF3A3A3A),
      Color(0xFF2C2C2C),
      Color(0xFF1E1E1E),
    ],
    this.stops = const [0.0, 0.25, 0.5, 0.75, 1.0],
    this.duration = const Duration(milliseconds: 1400),
    this.curve = Curves.easeInOutSine,
  });
}

// ─────────────────────────────────────────────
// ShimmerTheme — provide config to entire subtree
// ─────────────────────────────────────────────
class ShimmerTheme extends InheritedWidget {
  final ShimmerConfig config;

  const ShimmerTheme({super.key, required this.config, required super.child});

  static ShimmerConfig of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<ShimmerTheme>()?.config ??
        const ShimmerConfig();
  }

  @override
  bool updateShouldNotify(ShimmerTheme oldWidget) => config != oldWidget.config;
}

// ─────────────────────────────────────────────
// Shimmer — the core animated widget
// ─────────────────────────────────────────────
class Shimmer extends StatefulWidget {
  /// Width of the shimmer placeholder. Defaults to match parent.
  final double width;

  /// Height of the shimmer placeholder.
  final double height;

  /// Corner radius.
  final double borderRadius;

  /// Shape override — use [BoxShape.circle] for avatars.
  final BoxShape shape;

  /// Wrap a child inside the shimmer (optional).
  final Widget? child;

  /// Override config for this instance only (optional).
  final ShimmerConfig? config;

  const Shimmer({
    super.key,
    this.width = double.infinity,
    this.height = 16,
    this.borderRadius = 8,
    this.shape = BoxShape.rectangle,
    this.child,
    this.config,
  });

  /// Convenience: circular shimmer (e.g. avatar).
  const Shimmer.circle({
    super.key,
    required double size,
    this.child,
    this.config,
  }) : width = size,
       height = size,
       borderRadius = 0,
       shape = BoxShape.circle;

  @override
  State<Shimmer> createState() => _ShimmerState();
}

class _ShimmerState extends State<Shimmer> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _sweep;

  @override
  void initState() {
    super.initState();
    final cfg = widget.config ?? const ShimmerConfig();
    _controller = AnimationController(vsync: this, duration: cfg.duration)
      ..repeat();

    _sweep = Tween<double>(
      begin: -2,
      end: 2,
    ).animate(CurvedAnimation(parent: _controller, curve: cfg.curve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cfg = widget.config ?? ShimmerTheme.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final colors = isDark ? cfg.darkColors : cfg.lightColors;

    return AnimatedBuilder(
      animation: _sweep,
      builder: (_, __) {
        return Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            shape: widget.shape,
            borderRadius: widget.shape == BoxShape.circle
                ? null
                : BorderRadius.circular(widget.borderRadius),
            gradient: LinearGradient(
              begin: Alignment(_sweep.value - 1, 0),
              end: Alignment(_sweep.value + 1, 0),
              colors: colors,
              stops: cfg.stops,
            ),
          ),
          child: widget.child,
        );
      },
    );
  }
}

// ─────────────────────────────────────────────
// Ready-made skeleton building blocks
// ─────────────────────────────────────────────

/// A thin horizontal line placeholder.
class ShimmerLine extends StatelessWidget {
  final double? width;
  final double height;
  final double borderRadius;

  const ShimmerLine({
    super.key,
    this.width,
    this.height = 14,
    this.borderRadius = 6,
  });

  @override
  Widget build(BuildContext context) {
    return Shimmer(
      width: width ?? double.infinity,
      height: height,
      borderRadius: borderRadius,
    );
  }
}

/// A square/rectangle image placeholder.
class ShimmerBox extends StatelessWidget {
  final double width;
  final double height;
  final double borderRadius;

  const ShimmerBox({
    super.key,
    required this.width,
    required this.height,
    this.borderRadius = 8,
  });

  @override
  Widget build(BuildContext context) {
    return Shimmer(width: width, height: height, borderRadius: borderRadius);
  }
}

/// A circular avatar placeholder.
class ShimmerAvatar extends StatelessWidget {
  final double size;

  const ShimmerAvatar({super.key, this.size = 48});

  @override
  Widget build(BuildContext context) {
    return Shimmer.circle(size: size);
  }
}

/// A paragraph of shimmer lines with varying widths.
class ShimmerParagraph extends StatelessWidget {
  final int lines;
  final double lineHeight;
  final double spacing;

  const ShimmerParagraph({
    super.key,
    this.lines = 3,
    this.lineHeight = 14,
    this.spacing = 8,
  });

  // Last line is shorter to feel natural
  static const _widthFractions = [1.0, 0.92, 0.85, 0.70, 0.60];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: List.generate(lines, (i) {
            final fraction =
                _widthFractions[i.clamp(0, _widthFractions.length - 1)];
            return Padding(
              padding: EdgeInsets.only(bottom: i < lines - 1 ? spacing : 0),
              child: ShimmerLine(
                width: constraints.maxWidth * fraction,
                height: lineHeight,
              ),
            );
          }),
        );
      },
    );
  }
}

// ─────────────────────────────────────────────
// Example skeleton layouts
// ─────────────────────────────────────────────

/// List-item skeleton: avatar + lines.
class ShimmerListTile extends StatelessWidget {
  const ShimmerListTile({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const ShimmerAvatar(size: 48),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              ShimmerLine(height: 14),
              SizedBox(height: 8),
              ShimmerLine(height: 12, width: 160),
            ],
          ),
        ),
      ],
    );
  }
}

/// Grid of card skeletons.
class ShimmerGrid extends StatelessWidget {
  /// Number of items to show.
  final int itemCount;

  /// Number of columns.
  final int crossAxisCount;

  /// Ratio of each cell's width to its height.
  final double childAspectRatio;

  /// Gap between cells.
  final double spacing;

  /// Height of the image area inside each grid card.
  final double imageHeight;

  const ShimmerGrid({
    super.key,
    this.itemCount = 6,
    this.crossAxisCount = 2,
    this.childAspectRatio = 0.75,
    this.spacing = 12,
    this.imageHeight = 110,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: spacing,
        mainAxisSpacing: spacing,
        childAspectRatio: childAspectRatio,
      ),
      itemCount: itemCount,
      itemBuilder: (_, __) => _ShimmerGridCell(imageHeight: imageHeight),
    );
  }
}

/// Single grid cell skeleton.
class _ShimmerGridCell extends StatelessWidget {
  final double imageHeight;

  const _ShimmerGridCell({required this.imageHeight});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image placeholder
          ShimmerBox(
            width: double.infinity,
            height: imageHeight,
            borderRadius: 8,
          ),
          const SizedBox(height: 10),
          // Title line
          const ShimmerLine(height: 13),
          const SizedBox(height: 6),
          // Subtitle — shorter
          const ShimmerLine(height: 11, width: 80),
          const Spacer(),
          // Price / badge line
          const ShimmerLine(height: 13, width: 60),
        ],
      ),
    );
  }
}

/// Card skeleton: image banner + text block.
class ShimmerCard extends StatelessWidget {
  final double? width;

  const ShimmerCard({super.key, this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          ShimmerBox(width: double.infinity, height: 140, borderRadius: 8),
          SizedBox(height: 12),
          ShimmerLine(height: 16),
          SizedBox(height: 8),
          ShimmerParagraph(lines: 2),
        ],
      ),
    );
  }
}
