import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/*
 WidgetsFlutterBinding.ensureInitialized();
await LocalStorageService.instance.init();
*/
/// A singleton local storage service wrapping SharedPreferences.
/// Supports String, int, double, bool, and image (saved to app directory).
class LocalStorageService {
  LocalStorageService._internal();
  static final LocalStorageService instance = LocalStorageService._internal();

  SharedPreferences? _prefs;

  // ─────────────────────────────────────────
  //  Init
  // ─────────────────────────────────────────

  /// Must be called once before using any method, e.g. in main().
  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  SharedPreferences get _p {
    assert(_prefs != null, 'LocalStorageService.init() has not been awaited.');
    return _prefs!;
  }

  // ─────────────────────────────────────────
  //  String
  // ─────────────────────────────────────────

  Future<bool> setString(String key, String value) => _p.setString(key, value);

  String? getString(String key, {String? fallback}) =>
      _p.getString(key) ?? fallback;

  // ─────────────────────────────────────────
  //  Int
  // ─────────────────────────────────────────

  Future<bool> setInt(String key, int value) => _p.setInt(key, value);

  int? getInt(String key, {int? fallback}) => _p.getInt(key) ?? fallback;

  // ─────────────────────────────────────────
  //  Double
  // ─────────────────────────────────────────

  Future<bool> setDouble(String key, double value) => _p.setDouble(key, value);

  double? getDouble(String key, {double? fallback}) =>
      _p.getDouble(key) ?? fallback;

  // ─────────────────────────────────────────
  //  Bool
  // ─────────────────────────────────────────

  Future<bool> setBool(String key, {required bool value}) =>
      _p.setBool(key, value);

  bool? getBool(String key, {bool? fallback}) => _p.getBool(key) ?? fallback;

  // ─────────────────────────────────────────
  //  Image  (bytes → app documents directory)
  // ─────────────────────────────────────────

  /// Saves raw image bytes to the app's documents directory.
  /// Stores the resulting file path under [key] in SharedPreferences.
  /// Returns the saved [File] on success, null on failure.
  Future<File?> saveImage(
    String key,
    Uint8List bytes, {
    String extension = 'jpg',
  }) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final path =
          '${dir.path}/${key.replaceAll(RegExp(r'\W'), '_')}.$extension';
      final file = File(path);
      await file.writeAsBytes(bytes, flush: true);
      await _p.setString(_imageKey(key), path);
      return file;
    } catch (e) {
      debugPrint('[LocalStorageService] saveImage error: $e');
      return null;
    }
  }

  /// Saves an existing [File] object (e.g. from image_picker).
  /// Copies it to the documents directory and stores the path.
  Future<File?> saveImageFile(String key, File sourceFile) async {
    try {
      final bytes = await sourceFile.readAsBytes();
      final ext = sourceFile.path.split('.').last;
      return saveImage(key, bytes, extension: ext);
    } catch (e) {
      debugPrint('[LocalStorageService] saveImageFile error: $e');
      return null;
    }
  }

  /// Returns the stored [File] for [key], or null if not found / deleted.
  Future<File?> getImage(String key) async {
    final path = _p.getString(_imageKey(key));
    if (path == null) return null;
    final file = File(path);
    return await file.exists() ? file : null;
  }

  /// Returns the stored file path string (without checking existence).
  String? getImagePath(String key) => _p.getString(_imageKey(key));

  /// Deletes the image file from disk and removes the key.
  Future<void> deleteImage(String key) async {
    final path = _p.getString(_imageKey(key));
    if (path != null) {
      final file = File(path);
      if (await file.exists()) await file.delete();
    }
    await _p.remove(_imageKey(key));
  }

  String _imageKey(String key) => '__img__$key';

  // ─────────────────────────────────────────
  //  General helpers
  // ─────────────────────────────────────────

  /// Removes any single key (non-image).
  Future<bool> remove(String key) => _p.remove(key);

  /// Clears ALL keys from SharedPreferences (does NOT delete image files).
  Future<bool> clearAll() => _p.clear();

  /// Returns all stored keys.
  Set<String> get allKeys => _p.getKeys();

  bool containsKey(String key) => _p.containsKey(key);
}
